# AutoScientist Policy Package

Contents:

- `model.json`: workflow-policy model artifact.
- `neural_model/`: PyTorch manifest, weights, and neural model card when packaging a neural policy.
- `MODEL_CARD.md`: intended use, metrics, and limitations.
- `manifest.json`: package metadata, memory summary, and tool benchmark summary.
- `state_graph.json`: derived scientific state graph for hypotheses, entities, experiments, tools, and replay lineage.
- `replays/`: replay bundles for recent benchmark runs.

Use with AutoScientist:

```bash
python tools/package_policy_model.py
curl -X POST http://127.0.0.1:8000/memory/policy/predict \
  -H 'Content-Type: application/json' \
  -d '{"context":{"objective":"RA CD4 target prioritization","state_name":"TOOL_SELECTION"},"top_k":5}'
```

Packaged model version: `20260520065055`