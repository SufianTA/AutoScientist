# Neural Workflow Policy Artifact

Files:

- `manifest.json`: schema, vocab, action index, metrics, and sample predictions.
- `model.pt`: PyTorch state dict.
- `MODEL_CARD.md`: intended use, metrics, and limitations.

Predict from AutoScientist:

```bash
curl -X POST http://127.0.0.1:8000/memory/policy/predict \
  -H 'Content-Type: application/json' \
  -d '{"model_id":"MODEL_ID","context":{"objective":"RA target prioritization","state_name":"TOOL_SELECTION"},"top_k":5}'
```

Model version: `20260520065055`