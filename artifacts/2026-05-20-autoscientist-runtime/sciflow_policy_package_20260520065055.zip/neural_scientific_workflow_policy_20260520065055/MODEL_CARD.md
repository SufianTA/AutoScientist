# AutoScientist Scientific Workflow Policy Model

## Intended Use

This is not a biomedical language model and should not be used to make clinical claims. It is a workflow-policy model that ranks next scientific actions for AutoScientist, such as state transitions and tool calls, using prior run traces and outcomes.

## Model

- Name: `neural_scientific_workflow_policy`
- Version: `20260520065055`
- Type: `neural_scientific_workflow_policy`
- Artifact: `manifest.json`
- Framework: `pytorch`

## Training Data

- Examples: `2257`
- Distinct actions: `25`
- Source: AutoScientist run traces, tool calls, replay bundles, and run confidence.

## Metrics

- Top-1 training accuracy: `0.9202`
- Top-3 training accuracy: `1.0`
- Top-1 holdout accuracy: `0.9205`
- Top-3 holdout accuracy: `1.0`
- Holdout MRR: `0.9603`

## Scientific State Graph

- Nodes: `1106`
- Edges: `2795`
- `state_graph.json` exports hypothesis, entity, experiment, tool, replay, and confidence-evolution links.

## Limitations

- This is a workflow-action model, not a biomedical fact model.
- It learns from available traces, so quality improves as more benchmark runs are added.
- It should recommend workflow actions, not scientific truth.

## Recommended Next Step

Scale the benchmark corpus and compare this neural policy against the transparent baseline.